<?php
require_once("../connection.php");
require_once("../validation.php");
$course_id=$_POST['course_id'];

$query="DELETE FROM course WHERE course_id ='$course_id'";
$stmt = $conn->prepare($query);
$stmt->execute();
   
$return= [
    "status"=>1,
    "data"=>"",
    "message"=>"Deleted successfully"
];
return print_r(json_encode($return));

?>