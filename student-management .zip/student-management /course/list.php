<?php
require_once("../connection.php");
require_once("../validation.php");
$query="select *,c.name as c_name,e.name as emp_name from course c inner join employees e on c.emp_id=e.emp_id";
$stmt = $conn->query($query);
$result = $stmt->fetchAll(PDO::FETCH_ASSOC);


$return= [
    "status"=>1,
    "data"=>$result,
    "message"=>"Course List"
];
return print_r(json_encode($return));

?>