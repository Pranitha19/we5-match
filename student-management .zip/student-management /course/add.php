<?php
require_once("../connection.php");
require_once("../validation.php");
//Required Validation
if(isset($_POST)){
    $validationStatus=validation(['emp_id','name','type','duration','fee'],$_POST);
    if(count($validationStatus)){
        $return= [
            "status"=>0,
            "data"=>"",
            "message"=>implode(',',$validationStatus)." Required"
        ];
        return print_r(json_encode($return));    
    }

    //Student create
    $sql = "INSERT INTO course (emp_id, name, duration,type,fee) VALUES (?,?,?,?,?)";
    $conn->prepare($sql)->execute([$_POST['emp_id'],$_POST['name'],$_POST['duration'],$_POST['type'],$_POST['fee']]);
    $return= [
        "status"=>1,
        "data"=>"",
        "message"=>"Added Successfully"
    ];
        return print_r(json_encode($return));    
    // return print_r($return);
}
$return= [
    "status"=>0,
    "data"=>"",
    "message"=>"Method not allowed"
];
        return print_r(json_encode($return));    
// return print_r($return);
    


?>