<?php
require_once("../connection.php");
require_once("../validation.php");
if(isset($_POST['name'])){
    $validationStatus=validation(
        ['emp_id','name','duration','type','fee','course_id'],$_POST);
    if(count($validationStatus)){
        $return= [
            "status"=>0,
            "data"=>"",
            "message"=>implode(',',$validationStatus)." Required"
        ];
        return print_r(json_encode($return));    
    }

    $sql = "UPDATE course set name=?,duration=?,type=?,fee=? where course_id=?";
    $conn->prepare($sql)->execute([$_POST['name'],$_POST['duration'],$_POST['type'],$_POST['fee'],$_POST['course_id']]);


    $return= [
        "status"=>1,
        "data"=>"",
        "message"=>"Updated successfully"
    ];
    return print_r(json_encode($return)); 

}
?>