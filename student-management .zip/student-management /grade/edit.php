<?php
require_once("../connection.php");
require_once("../validation.php");
if(isset($_POST['grade'])){
    $validationStatus=validation(
        ['grade_id','student_id','course_id','grade','remark'],$_POST);
    if(count($validationStatus)){
        $return= [
            "status"=>0,
            "data"=>"",
            "message"=>implode(',',$validationStatus)." Required"
        ];
        return print_r(json_encode($return));    
    }

    $sql = "UPDATE grades set grade=?,remark=?,course_id=? where grade_id=?";
    $conn->prepare($sql)->execute([$_POST['grade'],$_POST['remark'],$_POST['course_id'],$_POST['grade_id']]);


    $return= [
        "status"=>1,
        "data"=>"",
        "message"=>"Updated successfully"
    ];
    return print_r(json_encode($return)); 

}
?>