<?php
require_once("../connection.php");
require_once("../validation.php");
$query="select * from attendance";
$stmt = $conn->query($query);
$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
$return= [
    "status"=>1,
    "data"=>$result,
    "message"=>"Attendance List"
];
return print_r(json_encode($return));

?>